# v1.9 Tax Invoice / official property fields verification

- Added whitelisted settings fields: taxInvoiceHeading, tinNumber, tourismRegistrationNumber, legalBusinessName, businessAddress, websiteUrl, bankDetails.
- Seed and migration defaults added for existing installations.
- Admin Website content form includes all official business/tax fields.
- Invoice PDF heading defaults to `TAX INVOICE` and includes invoice number.
- Invoice PDF includes saved legal business name, business address, TIN, tourism registration number, phone/email/website and optional bank details.
- Tax report PDF and Excel headers include legal business/TIN/tourism registration when provided.
- JavaScript syntax checks passed for server.js, lib/store.js, lib/reports.js and public/admin/admin.js.
