# Verification notes

Checked before packaging:

- JavaScript syntax check passed for server, libraries, public scripts and admin scripts.
- Beds24 mocked API test passed for token refresh, Booking.com-source import, room/unit mapping and direct booking push.
- Beds24 mocked API test passed for date modification and cancellation update.
- Existing server-side room conflict logic remains in the booking path.
- iCal URL validation was changed from a Booking.com-only hostname rule to HTTPS + public-IP validation to avoid rejecting legitimate redirected calendar hosts while still blocking private-network SSRF targets.
- Channel selection supports: off, Beds24, iCal, email, and iCal+email hybrid.
- Outgoing iCal excludes bookings imported from Booking.com/Beds24 to prevent channel loops.

A live Beds24 API call cannot be completed without the property's real Beds24 invite code/refresh token and room mapping. Run a manual Beds24 sync after configuration and verify one test reservation before opening the property to live web bookings.
