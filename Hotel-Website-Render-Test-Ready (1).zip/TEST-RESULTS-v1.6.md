# v1.6 report verification

Verified report calculation logic with realistic sample data:

- Green Tax lists each individual guest/GRC.
- Passport guest charged by taxable nights.
- Maldivian ID exempt.
- Work visa/resident permit exempt.
- Child under 2 exemption evaluated on the individual guest arrival date.
- Monthly TGST report includes service charge collected, staff count for the reporting period, distributed amount, and balance.
- Service Charge report lists staff allocations individually.
- Historical staff count uses start/end employment dates rather than current active status.
- GRC numbering resets by calendar year (GRC-2026-0001 -> GRC-2027-0001).
- Invoice/booking/confirmation counters remain year-scoped.
- Monthly and yearly range calculation verified.

Environment limitation: a fresh npm install timed out in the isolated build environment, so the Node PDFKit/ExcelJS binary export path was not freshly rendered here. Source syntax checks pass. Run npm install and perform one PDF + Excel export smoke test on the deployment server before launch.
