# Security / logic audit v1.2

Audit date: 2026-09-15

This file records the review of findings 8–37 supplied by the property owner.

| # | Finding | Audit result / action |
|---|---|---|
| 8 | Media upload accepts any type | Confirmed and fixed. Allowlist plus file-signature validation for JPG/PNG/WEBP/GIF/MP4/WEBM/MOV. |
| 9 | Media saved without extension | Confirmed and fixed. Random filenames now retain a safe MIME-derived extension. |
| 10 | Login shares only general limiter | Confirmed and fixed. Dedicated 10 failed attempts / 15 minutes limiter added. |
| 11 | JWT in localStorage for 12h, no revocation | Confirmed and fixed. HttpOnly SameSite=Strict cookie, 4-hour expiry, server-side session registry and logout revocation. |
| 12 | Settings accepts arbitrary req.body keys | Confirmed and fixed with a settings/contact whitelist. |
| 13 | Media PATCH Object.assign | Confirmed and fixed. Only caption, visible, featured and sort are editable. |
| 14 | Sensitive room/settings reads lack permit | Confirmed and fixed. Website settings require website permission; sync credentials/mapping require ical permission; a sanitized room endpoint is used for ordinary booking screens. |
| 15 | CSP disabled | Confirmed and fixed. Helmet CSP is enabled. Note: current UI still permits inline handlers/styles for compatibility; removing unsafe-inline entirely is a future hardening task. |
| 16 | iCal SSRF private-address gaps | Confirmed and fixed. Handles 0/8, loopback, RFC1918, link-local, CGNAT 100.64/10, multicast/reserved, IPv4-mapped IPv6 and IPv6 local ranges. Redirects are revalidated and HTTPS requests are DNS-pinned. |
| 17 | No staff password minimum | Confirmed and fixed. Minimum 10 characters server-side and in the admin UI. |
| 18 | Multer 1.x / old uuid audit findings | Manifest updated to Multer 2.x and unused uuid dependency removed. A fresh `npm audit` must be run after `npm install` on a networked deployment machine; package download/audit could not complete in the isolated build environment. |
| 19 | ADMIN_USERNAME/PASSWORD only seed once | Confirmed behavior. This is now documented explicitly and the admin UI has password-change/reset controls. Environment credentials intentionally do not overwrite a live database on restart. |
| 20 | Arrivals today uses UTC | Confirmed and fixed. Uses Indian/Maldives timezone. |
| 21 | Unknown report type returns summary | Confirmed and fixed. Unknown types return HTTP 400. |
| 22 | Overlapping rate periods silently win | Confirmed and fixed. Create/update rejects overlaps for the same category. |
| 23 | Green Tax charges children under 2 | Confirmed and fixed. DOB is used to exempt children under 2 at check-in while keeping the registration card/document record. |
| 24 | Invoice requires guest cards for all pax | Kept intentionally because the owner's later requirement is one registration card per guest, including tax-exempt guests. Under-2 guests are exempt from tax but still require their guest record. |
| 25 | Number counters do not restart yearly | Confirmed and fixed. Booking, confirmation and invoice counters are scoped by calendar year; GRC was already year-scoped. Existing numbers are scanned during migration to avoid duplicates. |
| 26 | Beds24 push reads stale snapshot IDs | Fixed. Persisted mapping uses the IDs returned by the Beds24 push result. |
| 27 | No direct-booking notifications | Fixed with optional SMTP guest + owner notifications. Booking still succeeds if SMTP is not configured and reports notification status. |
| 28 | No guest status/cancellation page | Fixed. Direct reservations return a private management link for status and cancellation requests. |
| 29 | No admin cancel booking | Fixed in API and admin UI. Beds24-linked cancellations are also pushed when IDs are available. |
| 30 | No edit/delete rooms/categories/rate periods | Fixed. CRUD endpoints and admin controls added. Rooms with booking history must be deactivated instead of deleted. |
| 31 | No media delete/user edit/deactivate/password | Fixed. Media delete and user activation/password controls added. |
| 32 | Cannot edit booking dates/rooms | Fixed. Admin booking update re-runs overlap protection. |
| 33 | No invoice/expense lists | Fixed. Admin finance screen lists invoices and expenses; invoice PDFs remain available. |
| 34 | Static JS/CSS cached for 1h | Confirmed and fixed. JS/CSS/HTML are sent no-cache/no-store. Cloudflare should also bypass cache for these paths. |
| 35 | Nginx 1MB default blocks uploads | Deployment issue confirmed. README now requires `client_max_body_size 35M`. |
| 36 | Single JSON datastore concurrency/growth | Partially mitigated, not eliminated. Cross-process lock, atomic writes and bounded logs are added. For one small guesthouse run one Node/PM2 instance. SQLite/PostgreSQL remains the recommended future upgrade. |
| 37 | README says change admin password but no control | Confirmed and fixed. Admin > Users & permissions now includes change/reset password controls. |

## Tax rule verification

Maldivians, resident permit holders and children under 2 at check-in are Green Tax exempt under current MIRA guidance. Guest registration records remain required for the property's audit/record workflow, including exempt guests.

## Verification performed

- `node -c` passed for server, library, public and admin JavaScript files.
- Static searches confirm old `contentSecurityPolicy:false`, localStorage token use, arbitrary media Object.assign, old media storage, old static 1-hour cache, and unused uuid dependency are removed.
- Green Tax unit checks passed for under-2 child, adult passport holder, Maldivian ID and work-visa guest.
- Final ZIP integrity is checked after packaging.

## Deployment checks still required

The build environment does not have network package installation or your live accounts. After upload to the server: run `npm install`, `npm audit`, configure `.env`, connect Beds24/iCal/email as desired, then perform one test website reservation and one test cancellation before opening public bookings.
