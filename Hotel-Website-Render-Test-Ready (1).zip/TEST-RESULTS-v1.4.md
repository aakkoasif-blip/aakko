# Guest House Booking System v1.4 verification

Verified on the packaged source before release:

- `server.js` and `lib/notify.js` pass `node --check`.
- Website reservation notification call is non-blocking; the HTTP response is sent before SMTP delivery runs.
- SMTP notification result is recorded back on the booking as sent / not-sent / error.
- Nodemailer connection timeout: 10 seconds.
- Nodemailer greeting timeout: 10 seconds.
- Nodemailer socket timeout: 15 seconds.
- Nodemailer file and URL content access are disabled for the SMTP transporter.
- Empty/unconfigured SMTP skips delivery.
- SMTP example credentials are commented out by default.
- Booking email IMAP credentials are commented out by default.
- `POST /api/admin/blocks` is wrapped by shared async error handling.
- `GET /api/admin/channel/settings` is wrapped by shared async error handling.
- `POST /api/admin/beds24/disconnect` is wrapped by shared async error handling.
- Nodemailer requirement updated to supported 10.x line (`^10.0.8`).
- ZIP integrity verified after packaging.

## Dependency audit note

An attempted `npm install --package-lock-only` in the isolated build environment timed out while contacting the package registry, so this build does not claim a live `npm audit` result from this environment. Run the following on the deployment server with normal npm registry access:

```bash
npm install
npm audit
```

If npm reports transitive vulnerabilities, run `npm audit fix` and re-test the application before going live.
