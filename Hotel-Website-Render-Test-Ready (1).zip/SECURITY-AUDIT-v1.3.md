# Security / correctness audit v1.3

The 12 findings supplied after v1.2 were rechecked against the source and patched where applicable.

1. Fixed `fs.openSync` lock mode argument (`0o600`, not an options object).
2. Added `dotenv` dependency and `require('dotenv').config()` as the first server statement.
3. Added strict real `YYYY-MM-DD` validation; new public/admin stays reject past check-ins in Maldives local date. Historical pricing remains allowed for invoices/imported records.
4. Added selected-room capacity validation for public/admin bookings and booking edits.
5. Added `app.set('trust proxy', 1)` for a single trusted reverse-proxy hop. Keep the Node port private behind Nginx.
6. Added `wrap()` Promise error forwarding to previously unguarded async routes, global Express error middleware, and unhandled-rejection logging.
7. `.env.example` already contains `NODE_ENV=production`; README now explicitly explains secure cookies and PM2 environment behavior.
8. Public reservation creation now returns a sanitized response and never exposes `manageTokenHash`.
9. README now documents dotenv and first-run-only `ADMIN_PASSWORD`.
10. README/Nginx example documents `client_max_body_size 35M`.
11. README documents Cloudflare bypass rules for `/admin*`, `/api/*`, JS and CSS.
12. Run `npm install && npm audit` on the deployment server. Dependency audit cannot be guaranteed from an offline build environment.

Other v1.2 fixes remain in place, including report type rejection, yearly numbering, Maldives-local dashboard dates, under-2 Green Tax exemption, CSP, upload filtering, SSRF hardening, and no-store frontend asset headers.
