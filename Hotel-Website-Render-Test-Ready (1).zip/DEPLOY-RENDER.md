# Free test deployment on Render

This package is prepared for a Render Free Web Service.

## Render settings

- Runtime: Node
- Plan: Free
- Build command: `npm install`
- Start command: `npm start`
- Health check: `/api/public/info`

## Environment variables

Set `ADMIN_PASSWORD` to a strong temporary password when Render asks for it.
`JWT_SECRET` is generated automatically by `render.yaml`.

After Render gives you the public URL, you can optionally add:

`PUBLIC_BASE_URL=https://your-service-name.onrender.com`

This is only needed for correct links in outgoing booking emails.

## Important testing limitation

This app currently stores its database and uploads as local files. Render Free has an ephemeral filesystem, so bookings/settings/uploads created during testing can disappear after the service spins down, restarts, or redeploys. Use this deployment for functional testing only, not real guest data.

## URLs after deployment

- Public website: `https://your-service-name.onrender.com/`
- Admin: `https://your-service-name.onrender.com/admin`

Admin username: `admin`
Admin password: the value you set for `ADMIN_PASSWORD`.
