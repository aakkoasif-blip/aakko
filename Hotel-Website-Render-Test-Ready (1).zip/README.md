# Guest House Booking System v1.4

Self-hosted guest house website, direct booking engine, admin backend, reports and selectable channel synchronization.

## Channel Manager choices

Open **Admin > Channel manager** and choose one active method:

- **Beds24**: recommended when you subscribe to Beds24. Uses Beds24 API V2. Booking.com sends reservations to Beds24, this website imports them, and website/admin bookings and room blocks can be pushed back to Beds24.
- **Booking.com iCal**: low-cost availability calendar sync per room.
- **Booking.com Email**: imports reservation details from a Booking.com mailbox. It does not guess room availability.
- **iCal + Email Hybrid**: iCal protects dates and email enriches reservation details.
- **Off**: no automatic channel synchronization.

All methods feed the same local room calendar and server-side overlap protection.

## Beds24 setup

1. Create/connect the property in Beds24 and map Booking.com inside Beds24.
2. In Beds24 go to Marketplace/API and generate an invite code.
3. Give the invite code these scopes as needed: read/write bookings, bookings-personal, inventory and properties.
4. In this website open **Admin > Channel manager**, paste the invite code and press **Connect Beds24**.
5. Press **Show Beds24 property / room IDs**.
6. Map each local physical room to its Beds24 Room Type ID. Add Unit ID when you use Beds24 physical units.
7. Select **Beds24 channel manager** as the active method and enable **push website/admin bookings and room blocks to Beds24**.
8. Run **Sync Beds24 now** once and check the result before going live.

The invite code is exchanged server-side for a Beds24 refresh token. The refresh token is stored in `data/beds24-secret.json` with restrictive file permissions, unless `BEDS24_REFRESH_TOKEN` is set in `.env`.

### Beds24 behavior

- Imports new Beds24 bookings.
- Updates dates and local room allocation when a Beds24 booking changes.
- Marks imported reservations cancelled when Beds24 reports cancellation.
- Recognizes Booking.com bookings using Beds24's Booking.com API source ID.
- Avoids creating a second local reservation when a website booking pushed to Beds24 comes back in the Beds24 feed.
- Pushes direct website bookings, admin bookings and room blocks to Beds24 when Beds24 mode + push is enabled.
- Records sync errors on the booking instead of silently claiming success.
- Automatic sync interval is configurable from the Channel Manager page, minimum 5 minutes.

**Important:** Booking.com-to-Beds24 mapping cannot be done by this website API. Complete that mapping in Beds24 first.

## iCal + email setup

Each local room can store a Booking.com iCal export URL. The website publishes its own outgoing iCal URL for every room as well. The iCal fetcher accepts HTTPS public calendar hosts and rejects local/private network addresses.

For Gmail email import, use an App Password, not your normal Gmail password:

```env
BOOKING_EMAIL_IMAP_HOST=imap.gmail.com
BOOKING_EMAIL_IMAP_PORT=993
BOOKING_EMAIL_IMAP_SECURE=true
BOOKING_EMAIL_USER=your-booking-email@gmail.com
BOOKING_EMAIL_APP_PASSWORD=your-app-password
BOOKING_EMAIL_FOLDER=INBOX
```

## Main features

- Responsive public website for phone, tablet and desktop.
- Editable hotel name, slogan, description, logo, fonts, colours, hero image/overlay, social links and Google Analytics ID.
- Room-category cards and hotel-wide photo/video gallery.
- Direct multi-room availability search and reservation.
- Server-side overlapping-booking protection.
- Single or multiple room blocks.
- Room categories, physical rooms, base rates and seasonal/quarter rates.
- Admin-configurable TGST, Green Tax and service charge.
- Lead-guest reservation first, then full passport records for Guest Registration Card processing.
- Unique booking, confirmation and invoice numbering.
- Invoice discounts and additional services.
- Expense records and reporting.
- Staff accounts with individual permissions.
- Audit trail and sync logs.
- Helmet headers, rate limiting, JWT login, bcrypt password hashes, upload limits and atomic JSON writes.

## Reports

Monthly or yearly PDF and Excel exports are available separately for:

- Combined financial summary
- Income / invoices
- Expenses
- TGST
- Green Tax
- Bookings

Examples:

```text
GET /api/admin/reports/summary/export.pdf?month=2026-09
GET /api/admin/reports/tgst/export.xlsx?year=2026
```

## Install

Requires Node.js 20+.

```bash
cd guesthouse-booking-system
cp .env.example .env
npm install
npm start
```

Public site: `http://SERVER:4100/`

Admin: `http://SERVER:4100/admin`

## Production notes

- Change the default admin password and JWT secret before going live.
- Back up `data/db.json`, `data/beds24-secret.json` (if used) and `public/uploads/`.
- Use one Node process with the included JSON store. Move to PostgreSQL before clustering/multiple writer processes.
- Put Nginx/HTTPS in front of Node.
- Do a live Beds24 test using your real invite code and room mapping before opening online booking to guests.
- iCal is not instant and does not carry complete guest/payment information.
- Email layouts can change, so uncertain messages are sent to review rather than guessed.

## Default development login

Username: `admin`

Password: `ChangeMe123!`

Change it for production.


## Private guest document storage
Guest registration cards support PDF/JPG/PNG/WEBP uploads up to 10 MB. Files are stored outside the public web directory in `private_uploads/guest-documents` and are served only through authenticated Guest Registration routes. Guest cards use yearly numbers such as GRC-2026-0001.

## Security and production notes (v1.2)

- Admin authentication uses an HttpOnly, SameSite=Strict cookie session with server-side session revocation. Sessions expire after 4 hours. Use the Log out button to invalidate the current session.
- Login has a dedicated brute-force limiter (10 failed attempts per 15 minutes, per IP) in addition to the general API limiter.
- Media uploads are restricted to JPG, PNG, WEBP, GIF, MP4, WEBM and MOV; uploaded files keep a safe extension so web servers send the correct content type.
- Guest identity documents are stored under `private_uploads/` and are never served by the public static directory.
- `ADMIN_USERNAME` and `ADMIN_PASSWORD` seed the database only on the very first start. After that, change passwords in Admin > Users & permissions. This avoids silently replacing a live password on every restart.
- Use one Node/PM2 process for this small-property JSON datastore. A cross-process lock now protects writes and audit/sync logs are pruned, but SQLite/PostgreSQL is still the recommended upgrade if the installation grows or multiple application instances are required.
- For Nginx, set `client_max_body_size 35M;` or larger, otherwise Nginx's default upload limit can reject hotel media before Node receives it.
- Do not cache `/admin/`, `/admin/admin.js`, `/app.js`, or CSS at Cloudflare. The application sends `no-cache, no-store` for JS/CSS/HTML.
- Set a long random `JWT_SECRET` and `NODE_ENV=production` before going live.

### Nginx example

```nginx
server {
    server_name your-domain.com www.your-domain.com;
    client_max_body_size 35M;

    location / {
        proxy_pass http://127.0.0.1:4100;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location ~* ^/(admin/.*\.(?:js|css)|app\.js|styles\.css)$ {
        proxy_pass http://127.0.0.1:4100;
        add_header Cache-Control "no-cache, no-store, must-revalidate" always;
    }
}
```

### Direct-booking email notifications

SMTP and IMAP are disabled by default in `.env.example`. Uncomment and configure them only when you intentionally enable those features. When SMTP is configured, a website reservation is saved and returned to the guest immediately; notification delivery runs afterward in the background. SMTP connections have 10-second connection/greeting timeouts and a 15-second socket timeout, and the delivery result is recorded on the booking. If `SMTP_HOST` is empty, notification sending is skipped without delaying the booking response.

### Environment loading and first-run admin

The server loads `.env` with `dotenv` at startup. Run `npm install` after extracting the ZIP so the dependency is installed. `ADMIN_USERNAME` and `ADMIN_PASSWORD` are used **only when the database is first created**. Changing them later does not replace an existing administrator password; use **Admin > Users & permissions / Change password** instead.

For production use set `NODE_ENV=production`. This makes the admin session cookie `Secure`, so serve the site over HTTPS. If using PM2, either keep `NODE_ENV=production` in `.env` or set it in the PM2 ecosystem environment.

### Reverse proxy / Cloudflare

Nginx must include `client_max_body_size 35M;` (or larger) for hotel media uploads. The application uses `trust proxy = 1`, intended for one trusted reverse-proxy hop such as local Nginx. Do not expose the Node port publicly when relying on this setting.

At Cloudflare, create cache bypass rules for `/admin*`, `/api/*`, `*.js`, and `*.css`. The origin also returns `no-cache, no-store` for HTML/JS/CSS, but the explicit Cloudflare rule prevents stale admin/public interfaces after deployment.

After deployment run:

```bash
npm install
npm audit
```


## v1.4 reliability fixes

- Direct reservations no longer wait for SMTP. The guest receives the booking response immediately after the reservation and channel step completes; email delivery is queued afterward and recorded on the booking.
- Nodemailer transport uses `connectionTimeout: 10000`, `greetingTimeout: 10000`, and `socketTimeout: 15000`.
- SMTP and Booking.com IMAP credentials are commented out in `.env.example` by default.
- Nodemailer dependency is `^10.0.8` (supported 10.x line for Node 20+).
- Remaining async channel/block routes use the shared `wrap()` error handler.

## Service charge & staff management (v1.5)

Admin now has a dedicated **Service charge & staff** page. These employee records are separate from website admin/staff login accounts.

You can:
- add an employee/staff ID, staff name, role/position, start date and notes;
- activate or deactivate staff without losing history;
- record a service-charge distribution date and the exact amount paid to each active staff member;
- keep distribution notes/payroll references;
- view and delete distribution entries;
- export a separate monthly/yearly Service Charge PDF or Excel report.

The TGST report calculates service charge collected from invoices and shows active staff count, total distributed, and the undistributed balance. The separate Service Charge report lists individual employee distributions. Staff with historical distribution records cannot be deleted; deactivate them instead.


## Post-deploy manual checks

After deployment:
1. Open `/admin` in a real browser with developer tools open. Click Sync, Cancel, Delete and Export actions and confirm there are no CSP errors in the console.
2. Change the default/initial admin password on first login.
3. Make one real reservation from the public website, then cancel it and confirm the rooms become available again.
4. Export at least one PDF and one Excel report on the live server to confirm fonts and file generation work correctly.

The three moderate `uuid` findings currently reported by `npm audit` are transitive dependencies of `exceljs`/`node-ical`; monitor upstream updates and re-run `npm audit` during future upgrades.

## v1.9 official business and Tax Invoice fields
Admin > Website content now includes official business/tax fields:
- Tax Invoice heading (defaults to `TAX INVOICE`)
- TIN / Tax Registration Number
- Tourism Registration / License Number
- Legal business / owner name
- Business address
- Website URL
- Bank details

These values are stored in settings. Tax Invoice PDFs automatically print the saved hotel/legal details, TIN, tourism registration, address, contact details, website, and optional bank details. Tax report PDF/Excel headers also include the legal business name, TIN and tourism registration when supplied.
