# v1.7 CSP / error-handler verification

## Fixed
- Added `scriptSrcAttr:["\'unsafe-inline\'"]` to Helmet CSP so the existing inline `onclick=` handlers used by the admin/public UI are permitted.
- Expected 4xx errors no longer dump full stack traces. Stack traces are logged only for status >= 500.

## Verified
- `node --check server.js` passes.
- Inline handler count was re-scanned in `public/` and is covered by the explicit `script-src-attr` directive.
- ZIP integrity tested after packaging.

## Browser/runtime note
A full browser launch was not possible in the isolated build environment because dependency installation timed out. The CSP semantics and source/header configuration were verified statically; the user independently reported all prior v1.6 runtime/regression tests passing except this CSP issue.
